import { Injectable } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { ErrorDialogComponent } from '../../components/error-dialog/error-dialog.component';

@Injectable({
  providedIn: 'root'
})
export class ErrorDialogService {

  constructor(public dialog: MatDialog) { }
    openDialog(error): void {
        let data = {};
        let reason = error.error ? error.error : error.statusText
        data = {
          reason: (reason ? reason : error.message),
          status: error.status,
          url: error.url,
          isSuccess: false
        };
        const dialogRef = this.dialog.open(ErrorDialogComponent, {
            width: '300px',
            data: data
        });

        dialogRef.afterClosed().subscribe(result => {
            console.log('The dialog was closed');
        });
    }

    openSuccessDialog(message): void {
      let data = {};
      data = {
        reason: message,
        status: '',
        url: '',
        isSuccess: true
      };
      const dialogRef = this.dialog.open(ErrorDialogComponent, {
          width: '300px',
          data: data
      });

      dialogRef.afterClosed().subscribe(result => {
          console.log('The dialog was closed');
      });
    }

  }
