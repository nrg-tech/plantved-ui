import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpRequest, HttpResponse, HttpErrorResponse } from '@angular/common/http';
import { VINItem } from 'src/app/models/vindata.model';
import { Observable, throwError, of } from 'rxjs';
import { map, catchError } from 'rxjs/operators';
import { ErrorDialogService } from '../error_dialog/error-dialog.service';
import { environment } from 'src/environments/environment.prod';
import { EnvService } from '../env/env.service';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
}

@Injectable({
  providedIn: 'root'
})

export class VinListService {
  constructor(private http: HttpClient, public errorDialogService: ErrorDialogService, private env: EnvService) { }

  private vinListUrl = this.env.apiUrl +  "/api/vin/list";

  public getVinList(): Observable<VINItem[]> {
    return this.http.get<VINItem[]>(this.vinListUrl)
    .pipe(
      map((data: any[]) => data.map((item: any) => new VINItem(
                            item.id,
                            item.vinId,
                            item.rid,
                            false,
                          ))

      ),
      catchError(error => {
        this.errorDialogService.openDialog(error);
        return throwError(error);
      })
    );
  }
}
