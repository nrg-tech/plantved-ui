import { TestBed } from '@angular/core/testing';

import { VinListService } from './vin-list.service';

describe('VinListService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: VinListService = TestBed.get(VinListService);
    expect(service).toBeTruthy();
  });
});
