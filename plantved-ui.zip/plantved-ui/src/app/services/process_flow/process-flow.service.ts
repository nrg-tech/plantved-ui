import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpRequest, HttpResponse, HttpErrorResponse } from '@angular/common/http';
import { throwError, of } from 'rxjs';
import { ErrorDialogService } from '../error_dialog/error-dialog.service';
import { EnvService } from '../env/env.service';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
}

@Injectable({
  providedIn: 'root'
})
export class ProcessFlowService {
  constructor(private http: HttpClient, public errorDialogService: ErrorDialogService, private env: EnvService) { }

  private startProcessUrl = this.env.apiUrl + "/api/process/start";
  private stopProcessUrl = this.env.apiUrl + "/api/process/stop";
  private stopAllProcessUrl = this.env.apiUrl + "/api/proces/stopAll";

  public startProcess(processName: String, processTime: string, totalProcessTime: string, requestBody: any) {
    var startUrl = this.startProcessUrl + "?processTime=" + processTime + "&totalProcessTime=" + totalProcessTime + "&processName=" + processName; 
  
    this.http.post(startUrl, requestBody, httpOptions, )
    .subscribe(
      res => {
        this.errorDialogService.openSuccessDialog(processName + " process completed successfully");
        console.log(res);
      },
      error => {
        console.log(error)
        this.errorDialogService.openDialog(error);
        return throwError(error);
      }
    );
  }

  public stopProcess(processName: String) {
    var stopUrl = this.stopProcessUrl + "?processName=" + processName;
    this.http.get(stopUrl, httpOptions)
    .subscribe(
      res => {
        this.errorDialogService.openSuccessDialog("Successfully stopped process " + processName);
        console.log(res)
      },
      error => {
        console.log(error)
        // this.errorDialogService.openDialog(error);
        return throwError(error);
      }
    );
  }

  public stopAllProcess() {
    this.http.get(this.stopAllProcessUrl, httpOptions)
    .subscribe(
      res => {
        this.errorDialogService.openSuccessDialog("Successfully stopped all processes");
        console.log(res)
      },
      error => {
        console.log(error)
        // this.errorDialogService.openDialog(error);
        return throwError(error);
      }
    );
  }
}
