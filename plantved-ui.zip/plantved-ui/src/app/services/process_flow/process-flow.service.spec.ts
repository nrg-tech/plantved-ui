import { TestBed } from '@angular/core/testing';

import { ProcessFlowService } from './process-flow.service';

describe('ProcessFlowService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ProcessFlowService = TestBed.get(ProcessFlowService);
    expect(service).toBeTruthy();
  });
});
