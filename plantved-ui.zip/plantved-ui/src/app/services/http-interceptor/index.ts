import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { LoggingInterceptorService } from './logging-interceptor.service';

export const httpInterceptorProviders = [
  { provide: HTTP_INTERCEPTORS, useClass: LoggingInterceptorService, multi: true }
]; 