export class VINItem {
    id: number;
    vinId: string;
    rid: string;
    isSelected: boolean = false;    

    constructor(id: number, vinId: string, rid: string, isSelected: boolean) {
      this.id = id;
      this.vinId = vinId;
      this.rid = rid;
      this.isSelected = isSelected;
    }
}