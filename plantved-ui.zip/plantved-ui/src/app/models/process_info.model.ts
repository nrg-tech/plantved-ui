export class ProcessInfo {
    id: number;
    displayName: string;
    processName: string;
  }