import { Component, OnInit, Input } from '@angular/core';
import { ProcessInfo } from '../../models/process_info.model';
import { VINItem } from '../../models/vindata.model';
import { VinListService } from '../../services/vin_list/vin-list.service';
import { ProcessFlowService } from 'src/app/services/process_flow/process-flow.service';
import { ErrorDialogService } from 'src/app/services/error_dialog/error-dialog.service';

@Component({
  selector: 'app-select-process',
  templateUrl: './select-process.component.html',
  styleUrls: ['./select-process.component.scss']
})

export class SelectProcessComponent implements OnInit {
  radioButtonItems: ProcessInfo[] = [];
  vinItems: VINItem[] = [];
  allVinItemsSelected: boolean = false;
  radioButtonIdSelected: number =-1;
  processInfoSelected: ProcessInfo;

  @Input() vinTime: string;
  @Input() processTime: string;

  constructor(private vinListService: VinListService, private processFlowService: ProcessFlowService, private errorDialogService: ErrorDialogService) { }

  ngOnInit() {
    this.radioButtonItems = [
       { id: 1, displayName: 'Production Plan Fixed Info', processName: "production_plan"},
       { id: 2, displayName: 'Mnemonics file', processName: "mnemonic_file"},
       { id: 3, displayName: 'VED file (Signature)', processName: "VED_file"}
    ]
    this.getVinList();   
  }

  getVinList(): void {
    this.vinListService.getVinList().subscribe( data => this.vinItems = data);
  }

  checkAll(): void {
    this.allVinItemsSelected = !this.allVinItemsSelected;
    this.vinItems = this.vinItems.map(item => {
      return { id: item.id, vinId: item.vinId, rid: item.rid, isSelected: this.allVinItemsSelected };
    });
  }

  checkboxValueChanged(item: VINItem) {
    item.isSelected = !item.isSelected;
  }

  startProcess(): void {
    var requestBody = this.createStartProcessParams()
    const filteredProcess: ProcessInfo[] = this.radioButtonItems.filter(item => item.id === this.radioButtonIdSelected)
    var totalProcessTime:string = ((this.processTime != null && this.processTime != "") ? this.processTime : "0")
    if (requestBody != null) {
      this.processFlowService.startProcess( filteredProcess[0].processName, this.vinTime, totalProcessTime, requestBody);
    }
  }

  stopProcess(): void {
    const filteredProcess: ProcessInfo[] = this.radioButtonItems.filter(item => item.id === this.radioButtonIdSelected)
    this.processFlowService.stopProcess(filteredProcess[0].processName);
  }

  enterNewProcessData(): void {
    this.radioButtonIdSelected = -1
    this.vinItems.map(item => item.isSelected = false)
    this.vinTime = null
    this.processTime = null
  }

  stopAllProcess(): void{
    this.processFlowService.stopAllProcess();
  }

  createStartProcessParams(): any {
    const selectedVins: VINItem[] = this.vinItems.filter(item => item.isSelected == true);
    var error = new Error()
    var totalProcessTime:string = ((this.processTime != null && this.processTime != "") ? this.processTime : "0")
    var isValid = false;
    if(this.radioButtonIdSelected == -1) {
      error.message = "Please select a process"
    } else if(selectedVins.length == 0) {
      error.message = "Please select atleast one VIN"
    } else if(this.vinTime == null || this.vinTime == "0") {
      error.message = "Please enter time between VINs"
    } else if(isNaN(parseInt(this.vinTime)) || isNaN(parseInt(totalProcessTime))){
      error.message = "Please enter numeric value for time fields"
    } else if (parseInt(totalProcessTime) !=0 && parseInt(totalProcessTime) < ((selectedVins.length - 1)* parseInt(this.vinTime) +1)) {
      error.message = "Please enter a higher value for total process time"
    } else {
      isValid = true
    }

    if (isValid) {
      const filteredProcess: ProcessInfo[] = this.radioButtonItems.filter(item => item.id === this.radioButtonIdSelected)
      // var requestBody = {"processName": filteredProcess[0].processName, "vinList": selectedVins, "processTime": this.vinTime, "totalProcessTime": totalProcessTime}
      var requestBody = selectedVins;
      return requestBody;
    } else {
      this.errorDialogService.openDialog(error);
      return null
    }
  }
}
