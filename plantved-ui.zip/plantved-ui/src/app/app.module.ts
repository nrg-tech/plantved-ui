import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatRadioModule } from '@angular/material/radio';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatDialogModule } from '@angular/material';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { SelectProcessComponent } from './components/select-process/select-process.component';
import { VinListService } from './services/vin_list/vin-list.service';
import { HttpClientModule } from '@angular/common/http';
import { HeaderComponent } from './components/header/header.component';
import { ErrorDialogComponent } from './components/error-dialog/error-dialog.component';
import { ErrorDialogService } from './services/error_dialog/error-dialog.service';
import { httpInterceptorProviders } from './services/http-interceptor';
import { ProcessFlowService } from './services/process_flow/process-flow.service';
import { EnvServiceProvider } from './services/env/env.service.provider';

@NgModule({
  declarations: [
    AppComponent,
    SelectProcessComponent,
    HeaderComponent,
    ErrorDialogComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    AppRoutingModule,
    MatRadioModule, 
    MatCheckboxModule,
    MatDialogModule,
    FormsModule,
    HttpClientModule
  ],
  entryComponents: [ErrorDialogComponent],

  providers: [VinListService, ProcessFlowService, ErrorDialogService, httpInterceptorProviders, EnvServiceProvider],
  bootstrap: [AppComponent]
})
export class AppModule { }
